import React, { Component } from "react";

class NoMatch extends Component {
  render() {
    return (
      <div className="center">
        <p>404 - No Page Exists</p>
      </div>
    );
  }
}

export default NoMatch;
